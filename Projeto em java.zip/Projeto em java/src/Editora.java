public class Editora {
   int id;
   String nome;
    int tipo;
}
