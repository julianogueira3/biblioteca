public class livro extends Material_Informacional {
     int id;
     String título;
     int ano;
     String edição;
     int volume;
     Editora editora;
     Autor autor;
}
