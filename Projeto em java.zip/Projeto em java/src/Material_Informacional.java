public abstract class Material_Informacional {
    int códigodebarras;
    int númerodaestante;
    int númeroexemplares;
   int númeroexemplaresdisponíveis;
}
