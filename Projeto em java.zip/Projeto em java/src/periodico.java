public class periodico extends Material_Informacional {
     int id;
   String título;
    int volume;

}
