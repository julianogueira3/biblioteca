public class Autor {
   int id;
  String nome;
  String sobrenome;
}
