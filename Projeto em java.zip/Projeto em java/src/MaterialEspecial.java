public class MaterialEspecial extends Material_Informacional{
    String tipo;
    String nome;
    String id;
}
